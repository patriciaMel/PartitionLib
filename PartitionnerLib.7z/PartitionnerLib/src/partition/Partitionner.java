/**
 * 
 */
package lib;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Patricia
 *
 */
public class Partitionner {
	
	public List<List<Integer>> Partition(List<Integer> liste, int taille){
		 List<List<Integer>> outputList=new ArrayList<List<Integer>>();
	        if(liste==null||liste.size()==0)
	            return null;
	        if(liste.size()<taille)
	            return null;

	        int modulo=liste.size()%taille;

	        int loopIterations=(liste.size()-modulo)/taille;

	        int lastPos=0;
	        for (int i=0;i<loopIterations;i++){
	        	List<Integer>temp=getSubList(liste,lastPos,taille);
	        	if(temp!=null)
	            outputList.add(temp);
	        	lastPos=lastPos+taille;
	        }

	        if(modulo!=0)
	        {
	        	List<Integer>temp0=getSubList(liste,lastPos,modulo);
	        	if(temp0!=null)
	        		outputList.add(temp0);
	        }

	    return outputList;
	}
	
	 private static List<Integer> getSubList(List<Integer>input,int lastPosition, int length){
	        if(lastPosition+length<=input.size())
	            return input.subList(lastPosition,lastPosition+length);
	        return null;
	}
}
