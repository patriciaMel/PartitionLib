Dans le dossier src, on retrouve 03 dossiers : 
1- Le dossier jars contenant la librairie qui peut �tre export� sous nimporte quel projet et utilis� par d'autres applications.
2- Le dossier partition contenant la fonction partition
3- Le dossier partitionTest contenant les differents cas de test de la fonction.
