/**
 * 
 */
package libTest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import lib.Partitionner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Patricia
 *
 */
public class PartitionnerTest {

	List<List<Integer>> expected;
	List<Integer> l1;
	Partitionner partitionner;
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		l1 = new ArrayList<Integer>();
		expected = new ArrayList<List<Integer>> ();
		partitionner=new Partitionner();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		
	}

	/**
	 * Test method for {@link lib.Partitionner#Partition(java.util.List, int)}.
	 */
	@Test
	public final void testPartition_Normal_Use_Case() {
		List<Integer> l1 = new ArrayList<Integer>();
		for (int i = 1; i < 12; i++) {
			l1.add(i);
		}
		
        List<List<Integer>> expected = new ArrayList<List<Integer>> ();
        
        expected.add(new ArrayList<Integer>(Arrays.asList(1,2)));
        expected.add(new ArrayList<Integer>(Arrays.asList(3,4)));
        expected.add(new ArrayList<Integer>(Arrays.asList(5,6)));
        expected.add(new ArrayList<Integer>(Arrays.asList(7,8)));
        expected.add(new ArrayList<Integer>(Arrays.asList(9,10)));
        expected.add(new ArrayList<Integer>(Arrays.asList(11)));
        
        
		assertEquals(expected, partitionner.Partition(l1, 2));
	}
	
	@Test
	public void partitioner_AGetNull_ReturnNull() {
		List<Integer> l1 = null;
		List<List<Integer>> expected = null;               
		assertEquals(expected, partitionner.Partition(l1, 2));
		assertEquals(expected, partitionner.Partition(l1, 0));
	}
	
	@Test
	public void partitioner_AGetEmptyList_ReturnNull() {
		List<Integer> l1 = new ArrayList<Integer>();
		List<List<Integer>> expected = null;               
		assertEquals(expected, partitionner.Partition(l1, 2));
		assertEquals(expected, partitionner.Partition(l1, 0));
	}
	
	@Test
	public void partitioner_AGetList_Size_5_Return_Same_One_List_Of_One_List_Size_5() {
		List<Integer> l1 = new ArrayList<Integer>();
		for (int i = 1; i <6; i++) {
			l1.add(i);
		}
		List<List<Integer>> expected = new ArrayList<List<Integer>>();
		expected.add(l1);
		assertEquals(expected, partitionner.Partition(l1, 5));
	}

}
